# VAPTGuard Pro - Implementation Plan

## Feature Lifecycle (4 States)

```
Draft ──► Develop ──► Test ──► Release
```

### State Meanings:

| State | Description |
|-------|-------------|
| **Draft** | Feature exists in 159 features list (from data file) |
| **Develop** | Has AI brief + schema collected, in global context |
| **Test** | Isolated local context - changes stay local to feature |
| **Release** | Ready for client builds |

### State Transition Rules (Adjacent States Only):

| Current | Can Go To |
|---------|-----------|
| **Draft** | Develop |
| **Develop** | Draft OR Test |
| **Test** | Develop OR Release |
| **Release** | Test |

### In-Place Editing:

- **In any state**, can edit metadata (dev_instruct, wireframe_url, note) without changing state
- Just an update action, not a transition
- Release features can be enhanced without reverting

---

## CHUNK 1: DRAFT Stage - Core Plugin Skeleton

**Purpose**: Plugin foundation - activate, create DB tables, register menus

> Features loaded from Feature-List-159-Adaptive-Updated.json start as **Draft** state

### Deliverables

| File | Source | Description |
|------|--------|-------------|
| `vaptguard.php` | Clone from source | Main plugin with constants |
| `includes/class-vaptguard-db.php` | Clone | Database handler |
| `includes/class-vaptguard-auth.php` | Clone | Auth stub |
| `includes/interfaces/interface-vaptguard-driver.php` | Clone | Driver interface |
| Data file | Already present | Feature-List-159-Adaptive-Updated.json |

### Changes Required

- [ ] Apply `vaptsecure` → `vaptguard` rename for ALL identifiers
- [ ] Update plugin header: "VAPTGuard Pro"
- [ ] Update text domain: `vaptguard`
- [ ] Update menu slugs
- [ ] Update REST namespace: `vaptguard/v1`
- [ ] Update DB tables: `wp_vaptguard_*`

### Test Criteria

- [ ] Plugin activates without errors
- [ ] 7 DB tables created (including feature_meta with wireframe_url, dev_instruct)
- [ ] Menu appears in admin
- [ ] Features load in Draft state
- [ ] No naming conflicts with VAPTSecure

### Exit Gate

> Plugin activates, menus appear, features load in Draft state

---

## CHUNK 2: DEVELOP Stage - REST API & Core Functions

**Purpose**: Core functionality - API, authentication, options

> Features can **transition to Develop** state, collecting AI brief + schema

### Deliverables

| File | Source | Description |
|------|--------|-------------|
| `includes/class-vaptguard-rest.php` | Clone | REST API handler |
| `includes/class-vaptguard-admin.php` | Clone | Admin page renderers |
| `includes/class-vaptguard-license-manager.php` | Clone | License system |
| `includes/class-vaptguard-config-cleaner.php` | Clone | Config utilities |
| `includes/debug-utils.php` | Clone | Debug functions |
| `assets/js/admin-modules/` | Copy | Admin JS modules |

### Changes Required

- [ ] Class renames: `VAPTSECURE_*` → `VAPTGUARD_*`
- [ ] Function renames: `vaptsecure_*` → `vaptguard_*`
- [ ] REST routes, options, transients, headers

### Test Criteria

- [ ] REST API responds
- [ ] Authentication works
- [ ] Transition modal works (Draft → Develop)

### Exit Gate

> REST API functional, can transition features to Develop state

---

## CHUNK 3: TEST Stage - Workbench & Transitions

**Purpose**: Workbench UI, state transitions, Test state with local context

> Features can **transition to Test** state (isolated local config)

### Deliverables

| File | Source | Description |
|------|--------|-------------|
| `includes/class-vaptguard-enforcer.php` | Clone | Core enforcer |
| `includes/class-vaptguard-workflow.php` | Clone | State handling |
| `includes/enforcers/` | Copy | Enforcer drivers |
| `includes/self-check/` | Copy | Self-check system |
| `assets/js/workbench.js` | Clone | Workbench UI |

### Changes Required

- [ ] Adjacent state transitions only (linear path)
- [ ] Test state = local context (isolated)
- [ ] Enforcer patterns, JS objects, REST calls

### Test Criteria

- [ ] Workbench loads
- [ ] All 159 features viewable
- [ ] Adjacent transitions work (no skip)
- [ ] Test state isolated from global

### Exit Gate

> Workbench functional, features can reach Test state

---

## CHUNK 4: RELEASE Stage - Build Generator & Client Views

**Purpose**: Client builds, in-place editing for Release features

> Release features available for builds. Can edit metadata without changing state.

### Deliverables

| File | Source | Description |
|------|--------|-------------|
| `includes/class-vaptguard-build.php` | Clone | Build generator |
| `assets/js/admin.js` | Clone | Domain Admin UI |
| `assets/js/client.js` | Clone | Client Status UI |
| `assets/css/admin.css` | Clone | Admin styles |

### Changes Required

- [ ] Build generator with Release features only
- [ ] Domain locking
- [ ] In-place editing for Release (update without state change)
- [ ] Client sees Release features only

### Test Criteria

- [ ] Client Status loads (Release only)
- [ ] Build generator creates ZIP
- [ ] Release features can be edited in place
- [ ] No conflicts with VAPTSecure

### Exit Gate

> Full plugin functional, builds generate from Release features

---

## Implementation Order

```
CHUNK 1: DRAFT       → Plugin activates, features in Draft
CHUNK 2: DEVELOP     → Features → Develop (transition works)
CHUNK 3: TEST        → Features → Test (local context)
CHUNK 4: RELEASE     → Features → Release (available for builds)
```

---

## Reference Files

- **`rename-mapping.json`** - All identifiers for programmatic rename

---

*Last updated: April 15, 2026*