# AI Agent Instructions: VAPT SaaS Build Generator Clone

## Mission: Clone the Complete SaaS Build Generator Platform

This is a **clone** (not replica) - meaning a fully functional independent copy that can coexist with the original on the same WordPress installation.

> **IMPORTANT**: Even a single naming collision can break one or both plugins. This document comprehensively lists ALL identifiers that MUST be changed.

This is a **WordPress Security SaaS Platform** with dual interfaces:
1. **Superadmin/Builder** - Full feature management & build generation
2. **WordPress Client** - Only sees enabled features for their domain

---

## FRONTEND INTERFACES (React/JavaScript)

The plugin uses **3 separate React interfaces** loaded based on user role:

### Interface Mapping

| File | Page | Access | Features Shown |
|------|------|-------|-------------|
| `client.js` | Status Page | All admins | Only enabled Release features |
| `workbench.js` | Workbench | Superadmin ONLY | All 159 features |
| `admin.js` | Domain Admin | Superadmin ONLY | Domain management |

### How Interfaces are Loaded

```php
// In vaptsecure.php - vaptsecure_enqueue_admin_assets() function
// Based on current screen ID:

// 1. Client Status (toplevel_page_vaptsecure)
// → Loads client.js
if ($screen->id === 'toplevel_page_vaptsecure') {
    wp_enqueue_script('vapt-client-js', ..., 'client.js', ...);
}

// 2. Workbench (vaptsecure-workbench)
// → Loads workbench.js
if (strpos($screen->id, 'vaptsecure-workbench') !== false) {
    wp_enqueue_script('vapt-workbench-js', ..., 'workbench.js', ...);
}

// 3. Domain Admin (vaptsecure-domain-admin)
// → Loads admin.js
if ($screen->id === 'toplevel_page_vaptsecure-domain-admin') {
    wp_enqueue_script('vapt-admin-js', ..., 'admin.js', ...);
}
```

### Interface Behavior Summary

| Interface | User Role | Purpose |
|-----------|----------|---------|
| **client.js** | Client Admin | View enabled features, toggle enforcement, see stats |
| **workbench.js** | Superadmin | Configure all 159 Features through Draft→Develop→Test→Release |
| **admin.js** | Superadmin | Manage domains, assign features, generate builds |

### Key JavaScript Dependencies

```
assets/
├── js/
│   ├── client.js         # 685 lines - Client dashboard
│   ├── workbench.js     # 618 lines - Superadmin feature config
│   ├── admin.js       # 4223 lines - Domain management
│   ├── admin-modules/ # Shared components
│   │   ├── domains.js
│   │   ├── design-modal.js
│   │   ├── field-mapping.js
│   │   ├── modals.js
│   │   ├── api-fetch-hotpatch.js
│   │   └── logger.js
│   └── modules/
│       ├── interface-generator.js
│       ├── aplus-generator.js
│       └── generated-interface.js
```

### Key Naming Summary

> **Critical**: Use global find/replace patterns:
> - `vaptsecure` → `vaptguard`
> - `VAPTSECURE` → `VAPTGUARD`
> - `vaptSecureSettings` → `vaptguardSecureSettings`
> - `[VAPT]` → `[VAPTGuard]`
> - `x-vapt-` → `x-vaptguard-`
> - `vapt_` → `vaptguard_` (prefixes only)

---

## DUAL INTERFACE ARCHITECTURE

### User Types & Access Levels

| Role | Menu Access | Features Visible | Interface Loaded |
|------|-----------|-----------------|--------------|---------------|
| **Superadmin** (You) | Workbench + Domain Admin | All 159 features in ALL states | workbench.js + admin.js |
| **Client Admin** | Only Status page | Only Release features for their domain | client.js |

### Menu Structure (Superadmin Sees)

```
VAPT Secure (Parent Menu)
├── VAPT Secure Status      → client.js (all admins)
├── VAPT Secure Workbench  → workbench.js (superadmin ONLY)
└── VAPT Secure Domain Admin → admin.js (superadmin ONLY)
```

### Menu Structure (Client Sees)

```
VAPT Secure (Parent Menu)
└── VAPT Secure Status      → client.js only
```

### Feature States & Visibility

| State | Superadmin Sees | Client Sees |
|-------|-----------------|-------------|
| Draft | ✅ Yes | ❌ No |
| Develop | ✅ Yes | ❌ No |
| Test | ✅ Yes | ❌ No |
| Release | ✅ Yes | ✅ Yes (if enabled for domain) |

---

## SUPERADMIN FEATURES (Builder)

### 1. Workbench (Feature Configuration)
- View all 159 features
- Configure features through states: Draft → Develop → Test → Release
- Set enforcement rules per feature
- Configure UI components
- Test and verify implementations

### 2. Domain Admin (Client Management)
- Add/edit/remove licensed domains
- Assign specific features to each domain
- Set license type per domain (Standard/Unlimited/Trial/Demo)
- View client build history
- Security event logs per domain

### 3. Build Generator
- Select Release features for a domain
- Generate client builds (ZIP or config-only)
- White-label options (plugin name, text domain, author)
- Version control for builds

---

## CLIENT FEATURES

### What Client Sees
- Only "VAPT Secure Status" menu item
- Only features in "Release" state
- Only features assigned to their domain
- Basic status dashboard
- Security events for their domain

### What Client CANNOT See
- Workbench page (removed)
- Domain Admin page (removed)
- Draft/Develop/Test features
- Features not assigned to their domain

---

## LICENSE TYPES

| License | Scope | Domain Lock | Features |
|---------|-------|------------|----------|
| `standard` | Single domain | Exact match | Only assigned |
| `developer_unbound` | Unlimited | Wildcard (*) | All features |
| `7-day-trial` | Single domain | Exact match | Limited time |
| `15-day-demo` | Single domain | Exact match | Demo set |

---

## BUILD GENERATOR FLOW

### Step 1: Feature Selection (Superadmin)
- Go to Workbench
- Configure features to "Release" state
- Only Release features available for builds

### Step 2: Domain Assignment (Superadmin)
- Go to Domain Admin
- Add client domain
- Assign specific features to that domain
- Set license type

### Step 3: Generate Build (Superadmin)
- Select domain
- Select features (from Release only)
- Choose build type: ZIP or Config-only
- Set version, white-label
- Generate

### Step 4: Client Deployment
- Client uploads ZIP/config to their WordPress
- Plugin activates with domain-lock
- Client sees only their enabled features
- Enforcement rules active

---

## AUTHENTICATION

### Superadmin Identity Check
- Uses SHA256 hashed user_login OR user_email
- Configured in `vaptsecure_get_superadmin_identity()`
- OTP (One-Time Password) for additional security

### Client Access
- Standard WordPress admin capability (`manage_options`)
- No OTP required

---

## COMPLETE RENAME REFERENCE

### Core Identity

| Element | Original | New |
|---------|----------|-----|
| Plugin Name | VAPTSecure Clean | VAPTGuard Pro |
| Text Domain | vaptsecure | vaptguard |
| Parent Menu | vaptsecure | vaptguard |
| Workbench | vaptsecure-workbench | vaptguard-workbench |
| Domain Admin | vaptsecure-domain-admin | vaptguard-domain-admin |

### REST API Routes

| Original | New |
|----------|-----|
| /wp-json/vaptsecure/v1/ | /wp-json/vaptguard/v1/ |

### JavaScript Window Objects & Settings

| Original | New |
|----------|-----|
| vaptSecureSettings | vaptguardSecureSettings |
| vaptLog | vaptguardLog |
| VAPT_DEBUG | VAPTGUARD_DEBUG |
| VAPTSECURE_GeneratedInterface | VAPTGUARD_GeneratedInterface |
| vapt_GeneratedInterface | vaptguard_GeneratedInterface |
| VAPT_ | VAPTGUARD_ (all global objects) |
| VAPT_Reference | VAPTGUARD_Reference |

### Console Log Prefix

| Original | New |
|----------|-----|
| [VAPT] | [VAPTGuard] |

### JavaScript Handles (wp_enqueue_script)

| Original | New |
|----------|-----|
| vapt-client-js | vaptguard-client-js |
| vapt-workbench-js | vaptguard-workbench-js |
| vapt-admin-js | vaptguard-admin-js |
| vapt-admin-logger | vaptguard-admin-logger |
| vapt-admin-modals | vaptguard-admin-modals |
| vapt-interface-generator | vaptguard-interface-generator |
| vapt-admin-domains | vaptguard-admin-domains |
| vapt-admin-field-mapping | vaptguard-admin-field-mapping |
| vapt-admin-design-modal | vaptguard-admin-design-modal |
| vapt-admin-api-fetch-hotpatch | vaptguard-admin-api-fetch-hotpatch |
| vapt-generated-interface-ui | vaptguard-generated-interface-ui |

### REST API Endpoints

| Original | New |
|----------|-----|
| vaptsecure/v1 | vaptguard/v1 |
| /wp-json/vaptsecure/v1/ | /wp-json/vaptguard/v1/ |

### HTTP Headers (All lowercase)

| Original | New |
|----------|-----|
| x-vapt-enforced | x-vaptguard-enforced |
| x-vapt-feature | x-vaptguard-feature |
| x-vapt-debug | x-vaptguard-debug |
| x-vapt-count | x-vaptguard-count |
| x-vapt-trace | x-vaptguard-trace |

### JavaScript URL Parameters

| Original | New |
|----------|-----|
| vaptsecure_header_check | vaptguard_header_check |
| vaptsecure_test_context | vaptguard_test_context |
| vaptsecure_test_spike | vaptguard_test_spike |

### DOM IDs & CSS Classes

| Original | New |
|----------|-----|
| vapt-admin-root | vaptguard-admin-root |
| vapt-workbench-root | vaptguard-workbench-root |
| vapt-client-root | vaptguard-client-root |
| vapt-status-badge | vaptguard-status-badge |
| vapt-loading | vaptguard-loading |
| vapt-sidebar-link | vaptguard-sidebar-link |
| vapt-feature-item | vaptguard-feature-item |
| vapt-workbench-sidebar | vaptguard-workbench-sidebar |
| vapt-workbench-list | vaptguard-workbench-list |

### LocalStorage Keys

| Original | New |
|----------|-----|
| vaptsecure_workbench_active_status | vaptguard_workbench_active_status |
| vaptsecure_workbench_active_feature | vaptguard_workbench_active_feature |

### Text Domain (for translations)

| Original | New |
|----------|-----|
| vaptsecure | vaptguard |

### Menu Slugs

| Original | New |
|----------|-----|
| vaptsecure | vaptguard |
| vaptsecure-workbench | vaptguard-workbench |
| vaptsecure-domain-admin | vaptguard-domain-admin |

### Database Tables

| Original | New |
|----------|-----|
| wp_vaptsecure_domains | wp_vaptguard_domains |
| wp_vaptsecure_domain_features | wp_vaptguard_domain_features |
| wp_vaptsecure_feature_status | wp_vaptguard_feature_status |
| wp_vaptsecure_feature_meta | wp_vaptguard_feature_meta |
| wp_vaptsecure_feature_history | wp_vaptguard_feature_history |
| wp_vaptsecure_domain_builds | wp_vaptguard_domain_builds |
| wp_vaptsecure_security_events | wp_vaptguard_security_events |

### Classes (34 total)

| Original | New |
|----------|-----|
| VAPTSECURE_REST | VAPTGUARD_REST |
| VAPTSECURE_Enforcer | VAPTGUARD_Enforcer |
| VAPTSECURE_Build | VAPTGUARD_Build |
| VAPTSECURE_Admin | VAPTGUARD_Admin |
| VAPTSECURE_DB | VAPTGUARD_DB |
| VAPTSECURE_Auth | VAPTGUARD_Auth |
| VAPTSECURE_License_Manager | VAPTGUARD_License_Manager |
| + 27 more | + 27 more |

### Functions (Key ones)

| Original | New |
|----------|-----|
| is_vaptsecure_superadmin() | is_vaptguard_superadmin() |
| vaptsecure_is_feature_allowed() | vaptguard_is_feature_allowed() |
| vaptsecure_is_domain_match() | vaptguard_is_domain_match() |
| vaptsecure_render_workbench_page() | vaptguard_render_workbench_page() |
| vaptsecure_render_client_status_page() | vaptguard_render_client_status_page() |

### Database Tables (7)

| Original | New |
|----------|-----|
| wp_vaptsecure_domains | wp_vaptguard_domains |
| wp_vaptsecure_domain_features | wp_vaptguard_domain_features |
| wp_vaptsecure_feature_status | wp_vaptguard_feature_status |
| wp_vaptsecure_feature_meta | wp_vaptguard_feature_meta |
| wp_vaptsecure_feature_history | wp_vaptguard_feature_history |
| wp_vaptsecure_domain_builds | wp_vaptguard_domain_builds |
| wp_vaptsecure_security_events | wp_vaptguard_security_events |

---

## BUILD GENERATOR (Key Logic)

When generating a client build (`class-vaptsecure-build.php` lines 550-590):

1. **Remove superadmin identity** - Stub to return "none"
2. **Remove workbench menu** - Not included in client build
3. **Remove domain admin menu** - Not included in client build
4. **Filter features** - Only Release state features
5. **Lock domain** - From build config
6. **Remove build functionality** - No creating builds for clients

---

## DATA FILES

### Primary Data File (Already Present)
`data/Feature-List-159-Adaptive-Updated.json`
- 159 features with full details
- Categories, severity, OWASP mappings
- Category: Configuration, Authentication, Injection, etc.

### Additional Data
- `interface_schema_v3.0.json` - UI component definitions
- `Enforcers/` - Server-specific rule templates

---

## SUCCESS CRITERIA

1. ✅ Both plugins activate on same WordPress without conflicts
2. ✅ No function/class/constant collisions
3. ✅ Different REST API endpoints
4. ✅ Superadmin sees Workbench + Domain Admin
5. ✅ Client sees only Status page
6. ✅ Client sees only assigned Release features
7. ✅ Build generator creates working client builds
8. ✅ Domain locking works in generated builds

---

## WordPress Plugin Standards

- Standard plugin headers
- register_activation_hook()
- register_uninstall_hook()
- Internationalization functions
- Capability checks
- Prepared SQL statements

---

## Supplemental Reference Files

For complete programmatic mappings, see:

- **`IMPLEMENTATION_PLAN.md`** - Chunked implementation strategy (Draft→Develop→Test→Release)
- **`rename-mapping.json`** - Machine-readable mapping for all 90+ identifiers

### Quick Reference Links

| Resource | Purpose |
|----------|---------|
| `rename-mapping.json` | All options, transients, functions, classes, CSS classes |
| `IMPLEMENTATION_PLAN.md` | Step-by-step chunk breakdown |

---

*Ready for AI execution*
*Last updated: April 15, 2026*
*Complete Dual-Interface Platform*