# AI Agent Instructions: VAPT SaaS Build Generator Replica

## Mission: Recreate the Complete SaaS Build Generator Platform

This is a **WordPress Security SaaS Platform** with dual interfaces:
1. **Superadmin/Builder** - Full feature management & build generation
2. **WordPress Client** - Only sees enabled features for their domain

---

## DUAL INTERFACE ARCHITECTURE

### User Types & Access Levels

| Role | Menu Access | Features Visible | Capabilities |
|------|-----------|-----------------|--------------|
| **Superadmin** (You) | Workbench + Domain Admin | All 159 features in ALL states | Full control |
| **Client Admin** | Only Status page | Only Release features enabled for their domain | Limited |

### Menu Structure (Builder Mode)

```
VAPT Secure (Parent Menu - visible to ALL admins)
├── VAPT Secure Status      → Client Status Page (all admins see their enabled features)
├── VAPT Secure Workbench  → Feature configuration (Superadmin ONLY)
└── VAPT Secure Domain Admin → Domain/License management (Superadmin ONLY)
```

### Feature States & Visibility

| State | Superadmin Sees | Client Sees |
|-------|-----------------|-------------|
| Draft | ✅ Yes | ❌ No |
| Develop | ✅ Yes | ❌ No |
| Test | ✅ Yes | ❌ No |
| Release | ✅ Yes | ✅ Yes (if enabled for domain) |

---

## SUPERADMIN FEATURES (Builder)

### 1. Workbench (Feature Configuration)
- View all 159 features
- Configure features through states: Draft → Develop → Test → Release
- Set enforcement rules per feature
- Configure UI components
- Test and verify implementations

### 2. Domain Admin (Client Management)
- Add/edit/remove licensed domains
- Assign specific features to each domain
- Set license type per domain (Standard/Unlimited/Trial/Demo)
- View client build history
- Security event logs per domain

### 3. Build Generator
- Select Release features for a domain
- Generate client builds (ZIP or config-only)
- White-label options (plugin name, text domain, author)
- Version control for builds

---

## CLIENT FEATURES

### What Client Sees
- Only "VAPT Secure Status" menu item
- Only features in "Release" state
- Only features assigned to their domain
- Basic status dashboard
- Security events for their domain

### What Client CANNOT See
- Workbench page (removed)
- Domain Admin page (removed)
- Draft/Develop/Test features
- Features not assigned to their domain

---

## LICENSE TYPES

| License | Scope | Domain Lock | Features |
|---------|-------|------------|----------|
| `standard` | Single domain | Exact match | Only assigned |
| `developer_unbound` | Unlimited | Wildcard (*) | All features |
| `7-day-trial` | Single domain | Exact match | Limited time |
| `15-day-demo` | Single domain | Exact match | Demo set |

---

## BUILD GENERATOR FLOW

### Step 1: Feature Selection (Superadmin)
- Go to Workbench
- Configure features to "Release" state
- Only Release features available for builds

### Step 2: Domain Assignment (Superadmin)
- Go to Domain Admin
- Add client domain
- Assign specific features to that domain
- Set license type

### Step 3: Generate Build (Superadmin)
- Select domain
- Select features (from Release only)
- Choose build type: ZIP or Config-only
- Set version, white-label
- Generate

### Step 4: Client Deployment
- Client uploads ZIP/config to their WordPress
- Plugin activates with domain-lock
- Client sees only their enabled features
- Enforcement rules active

---

## AUTHENTICATION

### Superadmin Identity Check
- Uses SHA256 hashed user_login OR user_email
- Configured in `vaptsecure_get_superadmin_identity()`
- OTP (One-Time Password) for additional security

### Client Access
- Standard WordPress admin capability (`manage_options`)
- No OTP required

---

## COMPLETE RENAME REFERENCE

### Core Identity

| Element | Original | New |
|---------|----------|-----|
| Plugin Name | VAPTSecure Clean | VAPTGuard Pro |
| Text Domain | vaptsecure | vaptguard |
| Parent Menu | vaptsecure | vaptguard |
| Workbench | vaptsecure-workbench | vaptguard-workbench |
| Domain Admin | vaptsecure-domain-admin | vaptguard-domain-admin |

### REST API Routes

| Original | New |
|----------|-----|
| /wp-json/vaptsecure/v1/ | /wp-json/vaptguard/v1/ |

### Classes (34 total)

| Original | New |
|----------|-----|
| VAPTSECURE_REST | VAPTGUARD_REST |
| VAPTSECURE_Enforcer | VAPTGUARD_Enforcer |
| VAPTSECURE_Build | VAPTGUARD_Build |
| VAPTSECURE_Admin | VAPTGUARD_Admin |
| VAPTSECURE_DB | VAPTGUARD_DB |
| VAPTSECURE_Auth | VAPTGUARD_Auth |
| VAPTSECURE_License_Manager | VAPTGUARD_License_Manager |
| + 27 more | + 27 more |

### Functions (Key ones)

| Original | New |
|----------|-----|
| is_vaptsecure_superadmin() | is_vaptguard_superadmin() |
| vaptsecure_is_feature_allowed() | vaptguard_is_feature_allowed() |
| vaptsecure_is_domain_match() | vaptguard_is_domain_match() |
| vaptsecure_render_workbench_page() | vaptguard_render_workbench_page() |
| vaptsecure_render_client_status_page() | vaptguard_render_client_status_page() |

### Database Tables (7)

| Original | New |
|----------|-----|
| wp_vaptsecure_domains | wp_vaptguard_domains |
| wp_vaptsecure_domain_features | wp_vaptguard_domain_features |
| wp_vaptsecure_feature_status | wp_vaptguard_feature_status |
| wp_vaptsecure_feature_meta | wp_vaptguard_feature_meta |
| wp_vaptsecure_feature_history | wp_vaptguard_feature_history |
| wp_vaptsecure_domain_builds | wp_vaptguard_domain_builds |
| wp_vaptsecure_security_events | wp_vaptguard_security_events |

---

## BUILD GENERATOR (Key Logic)

When generating a client build (`class-vaptsecure-build.php` lines 550-590):

1. **Remove superadmin identity** - Stub to return "none"
2. **Remove workbench menu** - Not included in client build
3. **Remove domain admin menu** - Not included in client build
4. **Filter features** - Only Release state features
5. **Lock domain** - From build config
6. **Remove build functionality** - No creating builds for clients

---

## DATA FILES

### Primary Data File (Already Present)
`data/Feature-List-159-Adaptive-Updated.json`
- 159 features with full details
- Categories, severity, OWASP mappings
- Category: Configuration, Authentication, Injection, etc.

### Additional Data
- `interface_schema_v3.0.json` - UI component definitions
- `Enforcers/` - Server-specific rule templates

---

## SUCCESS CRITERIA

1. ✅ Both plugins activate on same WordPress without conflicts
2. ✅ No function/class/constant collisions
3. ✅ Different REST API endpoints
4. ✅ Superadmin sees Workbench + Domain Admin
5. ✅ Client sees only Status page
6. ✅ Client sees only assigned Release features
7. ✅ Build generator creates working client builds
8. ✅ Domain locking works in generated builds

---

## WordPress Plugin Standards

- Standard plugin headers
- register_activation_hook()
- register_uninstall_hook()
- Internationalization functions
- Capability checks
- Prepared SQL statements

---

*Ready for AI execution*
*Last updated: April 15, 2026*
*Complete Dual-Interface Platform*