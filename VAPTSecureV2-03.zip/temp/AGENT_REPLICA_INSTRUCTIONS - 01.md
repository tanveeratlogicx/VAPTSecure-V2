# AI Agent Instructions: Create Coexisting VAPT Security Plugin (v3.0)

## Mission
Create a **completely independent** WordPress security plugin that can coexist with VAPTSecure-Clean on the same WordPress domain. This requires **complete namespace isolation** - no conflicts in:
- Plugin name
- Function names
- Class names
- Constants
- REST API routes
- Database tables
- Options
- Transients
- Menu slugs
- Script/style handles

---

## Coexistence Requirements

### Critical Rule
> Every identifier MUST be unique. Even a single conflict will break one or both plugins.

The original uses `vaptsecure` as base identifier. This version MUST use `vaptguard` (or similar unique identifier).

---

## Complete Rename Reference

### 1. Plugin Identity

| Element | Original (v2.0) | New (v3.0) |
|---------|-----------------|------------|
| Plugin Name | VAPTSecure Clean | **VAPTGuard Pro** |
| Text Domain | vaptsecure | **vaptguard** |
| Option Prefix | vaptsecure_ | **vaptguard_** |
| Transient Prefix | vaptsecure_ | **vaptguard_** |
| Capability | vaptsecure_ | **vaptguard_** |
| Database Prefix | wp_vaptsecure_ | **wp_vaptguard_** |

### 2. File Names

| Original | New |
|----------|-----|
| vaptsecure.php | **vaptguard.php** |
| class-vaptsecure-*.php | class-vaptguard-*.php |
| vapt-debug.txt | **vaptguard-debug.txt** |
| vapt-locked-config.php | **vaptguard-locked-config.php** |
| vapt-*-config-*.php | **vaptguard-*-config-*.php** |

### 3. Directory Names

| Original | New |
|----------|-----|
| /includes/ | /includes/ (keep) |
| /includes/enforcers/ | /includes/enforcers/ (keep) |
| /includes/self-check/ | /includes/self-check/ (keep) |
| /data/ | /data/ (keep) |
| /data/Enforcers/ | /data/Enforcers/ (keep) |
| /assets/ | /assets/ (keep) |
| /.ai/ | /.ai/ (keep) |

### 4. Class Names

| Original | New |
|----------|-----|
| VAPTSECURE_REST | **VAPTGUARD_REST** |
| VAPTSECURE_Enforcer | **VAPTGUARD_Enforcer** |
| VAPTSECURE_Build | **VAPTGUARD_Build** |
| VAPTSECURE_Admin | **VAPTGUARD_Admin** |
| VAPTSECURE_DB | **VAPTGUARD_DB** |
| VAPTSECURE_Auth | **VAPTGUARD_Auth** |
| VAPTSECURE_License_Manager | **VAPTGUARD_License_Manager** |
| VAPTSECURE_Config_Cleaner | **VAPTGUARD_Config_Cleaner** |
| VAPTSECURE_Schema_Validator | **VAPTGUARD_Schema_Validator** |
| VAPTSECURE_AI_Config | **VAPTGUARD_AI_Config** |
| VAPTSECURE_AI_Validator | **VAPTGUARD_AI_Validator** |
| VAPTSECURE_Environment_Detector | **VAPTGUARD_Environment_Detector** |
| VAPTSECURE_Deployment_Orchestrator | **VAPTGUARD_Deployment_Orchestrator** |
| VAPTSECURE_Migrations | **VAPTGUARD_Migrations** |
| VAPTSECURE_Workflow | **VAPTGUARD_Workflow** |
| VAPT_Check_Item | **VAPTGUARD_Check_Item** |
| VAPT_Self_Check_Result | **VAPTGUARD_Self_Check_Result** |
| VAPT_Audit_Log | **VAPTGUARD_Audit_Log** |
| VAPT_Auto_Correct | **VAPTGUARD_Auto_Correct** |
| VAPT_Cron | **VAPTGUARD_Cron** |
| VAPT_Lifecycle | **VAPTGUARD_Lifecycle** |
| VAPT_Self_Check | **VAPTGUARD_Self_Check** |
| VAPT_Hook_Driver | **VAPTGUARD_Hook_Driver** |
| VAPT_Apache_Driver | **VAPTGUARD_Apache_Driver** |
| VAPT_Nginx_Driver | **VAPTGUARD_Nginx_Driver** |
| VAPT_Apache_Deployer | **VAPTGUARD_Apache_Deployer** |
| VAPT_Nginx_Deployer | **VAPTGUARD_Nginx_Deployer** |
| VAPT_Config_Driver | **VAPTGUARD_Config_Driver** |
| VAPT_Config_Deployer | **VAPTGUARD_Config_Deployer** |
| VAPT_IIS_Driver | **VAPTGUARD_IIS_Driver** |
| VAPT_Caddy_Driver | **VAPTGUARD_Caddy_Driver** |
| VAPT_PHP_Driver | **VAPTGUARD_PHP_Driver** |
| VAPT_Diagnostics_Page | **VAPTGUARD_Diagnostics_Page** |
| VAPT_Rest_Base | **VAPTGUARD_Rest_Base** |

### 5. Function Names

| Original | New |
|----------|-----|
| vaptsecure_get_superadmin_identity() | **vaptguard_get_superadmin_identity()** |
| is_vaptsecure_superadmin() | **is_vaptguard_superadmin()** |
| vaptsecure_is_feature_allowed() | **vaptguard_is_feature_allowed()** |
| vaptsecure_is_domain_match() | **vaptguard_is_domain_match()** |
| vaptsecure_load_required_config() | **vaptguard_load_required_config()** |
| vaptsecure_get_configured_feature_keys() | **vaptguard_get_configured_feature_keys()** |
| vaptsecure_seed_client_release_features() | **vaptguard_seed_client_release_features()** |
| vaptsecure_check_requirements() | **vaptguard_check_requirements()** |
| vaptsecure_enforce_installation_limit() | **vaptguard_enforce_installation_limit()** |
| vaptsecure_initialize_services() | **vaptguard_initialize_services()** |
| vaptsecure_activate_plugin() | **vaptguard_activate_plugin()** |
| vaptsecure_manual_db_fix() | **vaptguard_manual_db_fix()** |
| vaptsecure_send_activation_email() | **vaptguard_send_activation_email()** |
| vapt_debug() | **vaptguard_debug()** |

**Prefix Pattern:** `vaptsecure_*` → `vaptguard_*`

### 6. Constants

| Original | New |
|----------|-----|
| VAPTSECURE_VERSION | **VAPTGUARD_VERSION** |
| VAPTSECURE_DATA_VERSION | **VAPTGUARD_DATA_VERSION** |
| VAPTSECURE_PATH | **VAPTGUARD_PATH** |
| VAPTSECURE_URL | **VAPTGUARD_URL** |
| VAPTSECURE_ACTIVE_DATA_FILE | **VAPTGUARD_ACTIVE_DATA_FILE** |
| VAPTSECURE_PATTERN_LIBRARY | **VAPTGUARD_PATTERN_LIBRARY** |
| VAPTSECURE_AI_INSTRUCTIONS | **VAPTGUARD_AI_INSTRUCTIONS** |
| VAPTSECURE_BUILD_VERSION | **VAPTGUARD_BUILD_VERSION** |
| VAPTSECURE_BUILD_PROFILE | **VAPTGUARD_BUILD_PROFILE** |
| VAPTSECURE_LICENSE_TYPE | **VAPTGUARD_LICENSE_TYPE** |
| VAPTSECURE_LICENSE_SCOPE | **VAPTGUARD_LICENSE_SCOPE** |
| VAPTSECURE_DOMAIN_LOCKED | **VAPTGUARD_DOMAIN_LOCKED** |
| VAPTSECURE_DOMAIN_WILDCARD | **VAPTGUARD_DOMAIN_WILDCARD** |
| VAPTSECURE_DOMAIN_LIMIT | **VAPTGUARD_DOMAIN_LIMIT** |
| VAPTSECURE_RESTRICT_FEATURES | **VAPTGUARD_RESTRICT_FEATURES** |
| VAPTSECURE_CONFIG_LOADED | **VAPTGUARD_CONFIG_LOADED** |
| VAPTSECURE_CONFIG_MISSING | **VAPTGUARD_CONFIG_MISSING** |
| VAPTSECURE_CONFIG_B64 | **VAPTGUARD_CONFIG_B64** |
| VAPTSECURE_FEATURE_* | **VAPTGUARD_FEATURE_* |
| VAPTSECURE_REQUIRE_WP | **VAPTGUARD_REQUIRE_WP** |
| VAPTSECURE_REQUIRE_PHP | **VAPTGUARD_REQUIRE_PHP** |
| VAPTSECURE_SECURITY_ALERT_EMAIL | **VAPTGUARD_SECURITY_ALERT_EMAIL** |
| VAPTSECURE_EXPECTS_CONFIG | **VAPTGUARD_EXPECTS_CONFIG** |

### 7. REST API Routes

| Original | New |
|----------|-----|
| vaptsecure/v1 | **vaptguard/v1** |
| /wp-json/vaptsecure/v1/ | **/wp-json/vaptguard/v1/** |

### 8. WordPress Admin Menus

| Original | New |
|----------|-----|
| vaptsecure | **vaptguard** |
| vaptsecure-domain-admin | **vaptguard-domain-admin** |
| vaptsecure-settings | **vaptguard-settings** |
| vaptsecure-workbench | **vaptguard-workbench** |
| vaptsecure-diagnostics | **vaptguard-diagnostics** |

### 9. Database Tables

| Original | New |
|----------|-----|
| wp_vaptsecure_domains | **wp_vaptguard_domains** |
| wp_vaptsecure_domain_features | **wp_vaptguard_domain_features** |
| wp_vaptsecure_feature_status | **wp_vaptguard_feature_status** |
| wp_vaptsecure_feature_meta | **wp_vaptguard_feature_meta** |
| wp_vaptsecure_feature_history | **wp_vaptguard_feature_history** |
| wp_vaptsecure_domain_builds | **wp_vaptguard_domain_builds** |
| wp_vaptsecure_security_events | **wp_vaptguard_security_events** |

### 10. WordPress Options

| Original | New |
|----------|-----|
| vaptsecure_version | **vaptguard_version** |
| vaptsecure_global_protection | **vaptguard_global_protection** |
| vaptsecure_active_feature_file | **vaptguard_active_feature_file** |
| vaptsecure_config_* | **vaptguard_config_* |
| vaptsecure_client_seeded_* | **vaptguard_client_seeded_* |
| vaptsecure_over_installation_limit | **vaptguard_over_installation_limit** |

### 11. Transients

| Original | New |
|----------|-----|
| vaptsecure_active_enforcements | **vaptguard_active_enforcements** |
| vaptsecure_network_site_count | **vaptguard_network_site_count** |
| vaptsecure_missing_config_notified | **vaptguard_missing_config_notified** |
| vaptsecure_invalid_config_notified | **vaptguard_invalid_config_notified** |
| vaptsecure_config_restore_notified | **vaptguard_config_restore_notified** |
| vapt_alert_* | **vaptguard_alert_* |

### 12. Script & Style Handles

| Original | New |
|----------|-----|
| vapt-admin-js | **vaptguard-admin-js** |
| vapt-admin-css | **vaptguard-admin-css** |
| vapt-admin-logger | **vaptguard-admin-logger** |
| vapt-admin-modals | **vaptguard-admin-modals** |
| vapt-interface-generator | **vaptguard-interface-generator** |

### 13. REST API Nonces

| Original | New |
|----------|-----|
| vaptsecure_scan_nonce | **vaptguard_scan_nonce** |

### 14. Capabilities

| Original | New |
|----------|-----|
| vaptsecure_manage | **vaptguard_manage** |
| vaptsecure_superadmin | **vaptguard_superadmin** |

### 15. Action/Filter Hooks

| Original | New |
|----------|-----|
| vaptsecure_feature_saved | **vaptguard_feature_saved** |
| vaptsecure_feature_enabled | **vaptguard_feature_enabled** |
| vaptsecure_feature_disabled | **vaptguard_feature_disabled** |
| vaptsecure_license_expired | **vaptguard_license_expired** |

### 16. Cron Hooks

| Original | New |
|----------|-----|
| vapt_daily_self_check | **vaptguard_daily_self_check** |
| vapt_license_check | **vaptguard_license_check** |

### 17. Data Files

| Original | New |
|----------|-----|
| interface_schema_v2.0.json | **interface_schema_v3.0.json** |
| enforcer_pattern_library_v2.0.json | **enforcer_pattern_library_v3.0.json** |
| ai_agent_instructions_v2.0.json | **ai_agent_instructions_v3.0.json** |
| vapt_driver_manifest_v2.0.json | **vapt_driver_manifest_v3.0.json** |
| VAPT_Driver_Reference_v2.0.php | **VAPT_Driver_Reference_v3.0.php** |

---

## Step-by-Step Implementation

### Step 1: Rename Main Plugin File

**File: vaptguard.php**

```php
<?php
/**
 * Plugin Name: VAPTGuard Pro
 * Description: Advanced WordPress Security & VAPT Protection Plugin
 * Version: 3.5.0
 * Author: [Your Name]
 * Text Domain: vaptguard
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) { exit; }

// Replace ALL occurrences:
// VAPTSECURE_* → VAPTGUARD_*
// vaptsecure_* → vaptguard_*
// VAPT_* → VAPTGUARD_*
```

### Step 2: Rename All Class Files

Create new class files with renamed classes:

```php
// File: includes/class-vaptguard-rest.php
class VAPTGUARD_REST { ... }

// File: includes/class-vaptguard-enforcer.php
class VAPTGUARD_Enforcer { ... }

// File: includes/class-vaptguard-build.php
class VAPTGUARD_Build { ... }
```

### Step 3: Update Database Table Creation

In `vaptguard_activate_plugin()`:

```php
$table_domains = "CREATE TABLE {$wpdb->prefix}vaptguard_domains (...";
$table_features = "CREATE TABLE {$wpdb->prefix}vaptguard_domain_features (...";
$table_status = "CREATE TABLE {$wpdb->prefix}vaptguard_feature_status (...";
// ... etc
```

### Step 4: Update REST API Namespace

In `register_routes()`:

```php
register_rest_route('vaptguard/v1', '/features', array(...));
// NOT vaptsecure/v1
```

### Step 5: Update Admin Menu Slugs

```php
add_menu_page('VAPTGuard Pro', 'VAPTGuard Pro', 'manage_options', 'vaptguard', ...);
add_submenu_page('vaptguard', 'Domains', 'Domains', 'manage_options', 'vaptguard-domains', ...);
```

### Step 6: Update Data File Constants

In vaptguard.php:

```php
define('VAPTGUARD_ACTIVE_DATA_FILE', 'interface_schema_v3.0.json');
define('VAPTGUARD_PATTERN_LIBRARY', 'enforcer_pattern_library_v3.0.json');
define('VAPTGUARD_AI_INSTRUCTIONS', 'ai_agent_instructions_v3.0.json');
```

### Step 7: Update Transients

```php
// Runtime cache
delete_transient('vaptguard_active_enforcements');
set_transient('vaptguard_active_enforcements', $enforced, HOUR_IN_SECONDS);
```

---

## WordPress Plugin Standards Checklist

### Required for WordPress.org

1. ✅ **Unique Text Domain** - Must match plugin folder name or be hyphenated
2. ✅ **Standard Headers** - Plugin Name, Version, Author, License, etc.
3. ✅ **Proper Activation** - `register_activation_hook()`
4. ✅ **Proper Cleanup** - `register_uninstall_hook()`
5. ✅ **Internationalization** - Use `__()`, `_e()`, `esc_html__()`, etc.
6. ✅ **Security** - Capability checks, nonces, sanitization
7. ✅ **Database Charset** - Use `$wpdb->get_charset_collate()`
8. ✅ **Prepared Statements** - Use `$wpdb->prepare()`

### Recommended

1. ✅ **Settings Link** - Add to Plugins admin page
2. ✅ **row_meta** - Version, FAQ links
3. ✅ **action_links** - Quick settings link

---

## File Structure After Rename

```
vaptguard/
├── vaptguard.php                    # Main plugin (was vaptsecure.php)
├── vaptguard-debug.txt             # Debug log (was vapt-debug.txt)
├── README.md
├── LICENSE
├── includes/
│   ├── class-vaptguard-rest.php     # (was class-vaptsecure-rest.php)
│   ├── class-vaptguard-enforcer.php # (was class-vaptsecure-enforcer.php)
│   ├── class-vaptguard-build.php
│   ├── class-vaptguard-admin.php
│   ├── class-vaptguard-db.php
│   ├── class-vaptguard-auth.php
│   ├── class-vaptguard-license-manager.php
│   ├── class-vaptguard-config-cleaner.php
│   ├── class-vaptguard-schema-validator.php
│   ├── class-vaptguard-ai-config.php
│   ├── class-vaptguard-ai-validator.php
│   ├── class-vaptguard-environment-detector.php
│   ├── class-vaptguard-deployment-orchestrator.php
│   ├── class-vaptguard-migrations.php
│   ├── class-vaptguard-workflow.php
│   ├── debug-utils.php
│   ├── interfaces/
│   │   └── interface-vaptguard-driver.php
│   ├── enforcers/
│   │   ├── class-vaptguard-hook-driver.php
│   │   ├── class-vaptguard-htaccess-driver.php
│   │   ├── class-vaptguard-nginx-driver.php
│   │   ├── class-vaptguard-apache-deployer.php
│   │   ├── class-vaptguard-nginx-deployer.php
│   │   ├── class-vaptguard-php-driver.php
│   │   ├── class-vaptguard-config-driver.php
│   │   ├── class-vaptguard-config-deployer.php
│   │   ├── class-vaptguard-iis-driver.php
│   │   └── class-vaptguard-caddy-driver.php
│   ├── rest/
│   │   └── class-vaptguard-rest-base.php
│   ├── self-check/
│   │   ├── class-vaptguard-check-item.php
│   │   ├── class-vaptguard-self-check-result.php
│   │   ├── class-vaptguard-audit-log.php
│   │   ├── class-vaptguard-auto-correct.php
│   │   ├── class-vaptguard-cron.php
│   │   ├── class-vaptguard-lifecycle.php
│   │   └── class-vaptguard-self-check.php
│   └── admin/
│       └── class-vaptguard-diagnostics-page.php
├── assets/
│   ├── css/
│   │   └── admin.css
│   └── js/
│       ├── admin.js
│       ├── client.js
│       ├── workbench.js
│       ├── admin-modules/
│       │   ├── modals.js
│       │   ├── field-mapping.js
│       │   ├── design-modal.js
│       │   ├── domains.js
│       │   ├── logger.js
│       │   └── api-fetch-hotpatch.js
│       └── modules/
│           ├── interface-generator.js
│           ├── aplus-generator.js
│           └── generated-interface.js
├── data/
│   ├── interface_schema_v3.0.json      # NEW (was v2.0)
│   ├── enforcer_pattern_library_v3.0.json
│   ├── ai_agent_instructions_v3.0.json
│   ├── vapt_driver_manifest_v3.0.json
│   ├── VAPT_Driver_Reference_v3.0.php
│   ├── vapt_driver_manifest_v2.0.json    # Keep for reference
│   └── Enforcers/
│       ├── apache-template.json
│       ├── nginx-template.json
│       ├── htaccess-template.json
│       ├── fail2ban-template.json
│       ├── php-functions-template.json
│       ├── wp-config-template.json
│       ├── wordpress-template.json
│       ├── server-cron-template.json
│       └── caddy-template.json
└── .ai/
    ├── SOUL.md
    ├── AGENTS.md
    └── rules/
```

---

## Conflict Detection Test

After installation, both plugins should show:

```php
// In VAPTSecure-Clean
echo VAPTSECURE_VERSION;        // 3.3.0
echo vaptsecure_version;       // 3.3.0

// In VAPTGuard Pro  
echo VAPTGUARD_VERSION;       // 3.5.0
echo vaptguard_version;        // 3.5.0

// Should be different!
```

---

## Key Functions for Coexistence

### 1. Debug Function Isolation
```php
function vaptguard_debug($message) {
    if (defined('VAPTGUARD_DEBUG') && VAPTGUARD_DEBUG) {
        error_log('[VAPTGuard] ' . $message);
    }
}
```

### 2. Option Isolation
```php
function vaptguard_get_option($key, $default = false) {
    return get_option('vaptguard_' . $key, $default);
}
```

### 3. Transient Isolation
```php
function vaptguard_set_transient($key, $value, $expire = 0) {
    return set_transient('vaptguard_' . $key, $value, $expire);
}
```

---

## Success Criteria

1. ✅ Both plugins activate without errors
2. ✅ No function/class/constant name collisions
3. ✅ Different REST API endpoints (`/vaptsecure/v1/` vs `/vaptguard/v1/`)
4. ✅ Different admin menus
5. ✅ Different database tables
6. ✅ Different WordPress options
7. ✅ Different transients
8. ✅ Can be activated/deactivated independently
9. ✅ Both show in WordPress Plugins list

---

## Notes

- Use find/replace with regex: `vaptsecure` → `vaptguard` globally
- Keep ALL original functionality
- Just change identifiers
- Update to 159 features in new data files

---

*Last updated: April 15, 2026*
*WordPress Plugin Standards Compliant*