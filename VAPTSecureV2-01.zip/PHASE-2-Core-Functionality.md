# Phase 2: Core Functionality

## Overview
REST API, authentication system, options/session management, transition modal.

---

## Phase Goal
Features can **transition to Develop** state. Transition modal collects dev_instruct, wireframe_url, note.

---

## Files to Process

### 2.1 REST API Handler
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-rest.php` | `includes/class-vaptguard-rest.php` | Full rename |

**Key components:**
- REST namespace: `vaptguard/v1`
- Feature endpoints (`/features`, `/features/update`, `/features/list`)
- Domain management endpoints
- License management endpoints
- File upload endpoint (`/upload-media`)

### 2.2 Admin Pages
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-admin.php` | `includes/class-vaptguard-admin.php` | Full rename |

**Key components:**
- Page renderers (status, workbench, admin)
- Asset enqueueing (JS handles)
- Superadmin capability checks

### 2.3 License Manager
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-license-manager.php` | `includes/class-vaptguard-license-manager.php` | Full rename |

### 2.4 Config Cleaner
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-config-cleaner.php` | `includes/class-vaptguard-config-cleaner.php` | Full rename |

### 2.5 Environment Detector
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-environment-detector.php` | `includes/class-vaptguard-environment-detector.php` | Full rename |

### 2.6 Debug Utils
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/debug-utils.php` | `includes/debug-utils.php` | Constant rename only |

### 2.7 REST Base
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/rest/class-vaptsecure-rest-base.php` | `includes/rest/class-vaptguard-rest-base.php` | Full rename |

### 2.8 Admin JS Modules (Copy)
| Source | Target |
|--------|--------|
| `assets/js/admin-modules/logger.js` | Copy |
| `assets/js/admin-modules/api-fetch-hotpatch.js` | Copy |
| `assets/js/admin-modules/modals.js` | Copy |
| `assets/js/admin-modules/field-mapping.js` | Copy |
| `assets/js/admin-modules/design-modal.js` | Copy |
| `assets/js/admin-modules/domains.js` | Copy |

---

## Renames for Phase 2

### REST API Routes
```
/wp-json/vaptsecure/v1/*  → /wp-json/vaptguard/v1/*
```

### HTTP Headers
```
x-vapt-enforced    → x-vaptguard-enforced
x-vapt-feature    → x-vaptguard-feature
x-vapt-debug      → x-vaptguard-debug
x-vapt-count      → x-vaptguard-count
x-vapt-trace      → x-vaptguard-trace
```

### Query Parameters
```
vaptsecure_header_check   → vaptguard_header_check
vaptsecure_test_context → vaptguard_test_context
vaptsecure_test_spike   → vaptguard_test_spike
```

### JavaScript Handles (wp_enqueue_script)
```
vapt-admin-logger             → vaptguard-admin-logger
vapt-admin-api-fetch-hotpatch → vaptguard-admin-api-fetch-hotpatch
vapt-admin-modals           → vaptguard-admin-modals
vapt-admin-field-mapping   → vaptguard-admin-field-mapping
vapt-admin-design-modal    → vaptguard-admin-design-modal
vapt-admin-domains        → vaptguard-admin-domains
```

### JavaScript Window Objects
```
window.vaptSecureSettings → window.vaptguardSecureSettings
window.vaptLog           → window.vaptguardLog
```

### LocalStorage Keys
```
vaptsecure_workbench_active_status   → vaptguard_workbench_active_status
vaptsecure_workbench_active_feature  → vaptguard_workbench_active_feature
```

### Additional Options
```
vaptsecure_global_protection            → vaptguard_global_protection
vaptsecure_global_protection_prev      → vaptguard_global_protection_prev
vaptsecure_over_installation_limit    → vaptguard_over_installation_limit
vaptsecure_hidden_json_files          → vaptguard_hidden_json_files
vaptsecure_removed_json_files         → vaptguard_removed_json_files
vaptsecure_config_original_b64        → vaptguard_config_original_b64
vaptsecure_config_original_hash      → vaptguard_config_original_hash
vaptsecure_config_original_path     → vaptguard_config_original_path
vaptsecure_config_current_b64       → vaptguard_config_current_b64
vaptsecure_config_last_sync         → vaptguard_config_last_sync
```

### Additional Transients
```
vaptsecure_active_enforcements         → vaptguard_active_enforcements
vaptsecure_missing_config_notified  → vaptguard_missing_config_notified
vaptsecure_network_site_count       → vaptguard_network_site_count
```

---

## Transition Modal (Draft → Develop)

When a feature transitions from Draft to Develop:

### Modal Fields:
1. **Internal Note** - Reason for transition
2. **Development Instructions (AI Guidance)** - dev_instruct field
3. **Wireframe / Design URL** - wireframe_url field

### DB Storage:
- `dev_instruct` → saved to `wp_vaptguard_feature_meta`
- `wireframe_url` → saved to `wp_vaptguard_feature_meta`
- History record → saved to `wp_vaptguard_feature_history`

---

## Test Criteria (Phase 2)

- [ ] REST API responds at `/wp-json/vaptguard/v1/status`
- [ ] Feature endpoints work (`/features`, `/features/update`)
- [ ] Domain endpoints work
- [ ] License endpoints work
- [ ] File upload works
- [ ] Authentication works:
  - [ ] Superadmin identity check
  - [ ] OTP flow
- [ ] Options save/retrieve correctly
- [ ] Transition modal displays (Draft → Develop)
- [ ] dev_instruct saves to DB
- [ ] wireframe_url saves to DB
- [ ] Note saves to history table
- [ ] JavaScript loads without errors

---

## Exit Gate

> Phase 2 COMPLETE when: REST API functional, authentication works, transition modal works, features can transition to Develop state

---

## Files Created

After Phase 2, additional files:
```
VAPTSecureV2/
├── includes/
│   ├── class-vaptguard-rest.php         # ✓ Clone
│   ├── class-vaptguard-admin.php       # ✓ Clone
│   ├── class-vaptguard-license-manager.php  # ✓ Clone
│   ├── class-vaptguard-config-cleaner.php  # ✓ Clone
│   ├── class-vaptguard-environment-detector.php # ✓ Clone
│   ├── debug-utils.php               # ✓ Clone
│   └── rest/
│       └── class-vaptguard-rest-base.php  # ✓ Clone
└── assets/js/admin-modules/
    ├── logger.js                     # ✓ Copy
    ├── api-fetch-hotpatch.js         # ✓ Copy
    ├── modals.js                   # ✓ Copy
    ├── field-mapping.js            # ✓ Copy
    ├── design-modal.js            # ✓ Copy
    └── domains.js                # ✓ Copy
```

*Phase 2 - Ready for iteration*