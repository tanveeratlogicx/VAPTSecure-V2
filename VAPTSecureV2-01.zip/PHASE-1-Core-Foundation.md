# Phase 1: Core Foundation

## Overview
Plugin foundation - activate, create DB tables, register menus, load features in Draft state.

---

## Phase Goal
Plugin activates successfully with 159 features loaded in **Draft** state.

---

## Files to Process

### 1.1 Main Plugin File
| Source | Target | Required Changes |
|--------|--------|------------------|
| `vaptsecure.php` | `vaptguard.php` | All renames |

**Key components in this file:**
- Plugin header
- Constants (VERSION, PATH, URL, etc.)
- Menu registration
- DB table creation (7 tables)
- Feature loading from data file
- Activation hook
- Required files include

### 1.2 Database Handler
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-db.php` | `includes/class-vaptguard-db.php` | Class rename |

**Key functions:**
- DB connection methods
- Feature status methods
- Global protection toggle

### 1.3 Auth Stub
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/class-vaptsecure-auth.php` | `includes/class-vaptguard-auth.php` | Class rename |

**Note**: This is a stub - full auth in Phase 2

### 1.4 Driver Interface
| Source | Target | Required Changes |
|--------|--------|------------------|
| `includes/interfaces/interface-vaptsecure-driver.php` | `includes/interfaces/interface-vaptguard-driver.php` | Interface rename |

### 1.5 Data File
| Source | Status |
|--------|--------|
| `data/Feature-List-159-Adaptive-Updated.json` | Already present - no copy needed |

---

## Rename Patterns for Phase 1

### Constants
```
VAPTSECURE_VERSION         → VAPTGUARD_VERSION
VAPTSECURE_DATA_VERSION  → VAPTGUARD_DATA_VERSION
VAPTSECURE_PATH          → VAPTGUARD_PATH
VAPTSECURE_URL           → VAPTGUARD_URL
VAPTSECURE_ACTIVE_DATA_FILE → VAPTGUARD_ACTIVE_DATA_FILE
VAPTSECURE_PATTERN_LIBRARY → VAPTGUARD_PATTERN_LIBRARY
VAPTC_VERSION           → VAPTG_VERSION
VAPTC_PATH              → VAPTG_PATH
VAPTC_URL               → VAPTG_URL
```

### Menu Slugs
```
vaptsecure          → vaptguard
vaptsecure-workbench → vaptguard-workbench
vaptsecure-domain-admin → vaptguard-domain-admin
```

### Database Tables
```
wp_vaptsecure_domains          → wp_vaptguard_domains
wp_vaptsecure_domain_features → wp_vaptguard_domain_features
wp_vaptsecure_feature_status  → wp_vaptguard_feature_status
wp_vaptsecure_feature_meta    → wp_vaptguard_feature_meta
wp_vaptsecure_feature_history → wp_vaptguard_feature_history
wp_vaptsecure_domain_builds   → wp_vaptguard_domain_builds
wp_vaptsecure_security_events → wp_vaptguard_security_events
```

### Options
```
vaptsecure_active_feature_file → vaptguard_active_feature_file
vaptsecure_version            → vaptguard_version
```

### WordPress Option Calls (all)
```
update_option('vaptsecure_*', ...) → update_option('vaptguard_*', ...)
get_option('vaptsecure_*', ...)    → get_option('vaptguard_*', ...)
delete_option('vaptsecure_*', ...)   → delete_option('vaptguard_*', ...)
```

### Transient Calls (all)
```
set_transient('vaptsecure_*', ...) → set_transient('vaptguard_*', ...)
get_transient('vaptsecure_*', ...) → get_transient('vaptguard_*', ...)
delete_transient('vaptsecure_*', ...) → delete_transient('vaptguard_*', ...)
```

### Functions (all)
```
vaptsecure_*   → vaptguard_*
is_vaptsecure_* → is_vaptguard_*
```

### Classes (all)
```
VAPTSECURE_*   → VAPTGUARD_*
```

### Text Domain
```
'vaptsecure'  → 'vaptguard'
```

### Console Prefix
```
[VAPT]  → [VAPTGuard]
```

### REST API Namespace
```
vaptsecure/v1  → vaptguard/v1
```

---

## Test Criteria (Phase 1)

- [ ] Plugin activates without errors
- [ ] 7 database tables created:
  - [ ] vaptguard_domains
  - [ ] vaptguard_domain_features
  - [ ] vaptguard_feature_status
  - [ ] vaptguard_feature_meta (with wireframe_url, dev_instruct columns)
  - [ ] vaptguard_feature_history
  - [ ] vaptguard_domain_builds
  - [ ] vaptguard_security_events
- [ ] Menu "VAPTGuard Pro" appears in admin
- [ ] Submenus:
  - [ ] VAPTGuard Pro Status
  - [ ] VAPTGuard Workbench
  - [ ] VAPTGuard Domain Admin
- [ ] Features load from JSON file in Draft state
- [ ] No naming conflicts with VAPTSecure

---

## Exit Gate

> Phase 1 COMPLETE when: Plugin activates, menus appear, 7 DB tables created, features load in Draft state

---

## Files Created

After Phase 1, these files should exist:
```
VAPTSecureV2/
├── vaptguard.php                          # ✓ Created via clone
├── includes/
│   ├── class-vaptguard-db.php            # ✓ Clone
│   ├── class-vaptguard-auth.php          # ✓ Clone (stub)
│   └── interfaces/
│       └── interface-vaptguard-driver.php  # ✓ Clone
├── data/
│   └── Feature-List-159-Adaptive-Updated.json  # (already present)
```

*Phase 1 - Ready for iteration*